1. The resolution of suit.jpg is changed to be used in "pose generation" model
2. Move two folders: There are two folders "densepose" and "detectron2" at following location. 
location: (your location)\IDM-VTON\gradio_demo
move those two folders into (your location)\IDM-VTON
3. extract_densepose.py is staring point for generating pose. You must put it at (your location)\IDM-VTON
4. you must substitute base.py, densepose_outputs_iuv.py in (your location)\IDM-VTON\densepose\vis with the same name files in the zip.
5. you must substitute extract_upper_cloth in (your location)\IDM-VTON with the same name file in the zip.