import os
import torch
import numpy as np
from PIL import Image
from preprocess.humanparsing.run_parsing import Parsing
import cv2
def remove_zipper_line(mask, ratio=0.2):
    """
    Function to remove the zipper area in the middle of the upper clothing mask.
    :param mask: Upper clothing mask (255=upper clothing, 0=background)
    :param ratio: The percentage of the image width to remove from the center (default is 20%)
    :return: Mask with the zipper area removed
    """
    h, w = mask.shape
    print(h)
    center = w // 2
    zipper_width = int(w * ratio / 2)
    mask[:, center - zipper_width:center + zipper_width] = 0
    return mask

def extract_upper_cloth(input_image_path, output_mask_path,  densepose_path, gpu_id=0, remove_zipper=True):
     # Initialize the parsing class (Load the ONNX model)
    parser = Parsing(gpu_id=gpu_id)

    # Load the input image (in PIL format)
    input_image = Image.open(input_image_path).convert("RGB")

    # Perform parsing
    parsed_image, _ = parser(input_image) # parsed_image is a PIL image (palette applied to indexed image)

    # Convert to numpy array
    parsed_np = np.array(parsed_image)

    # Extract only the upper clothing area (class ID 4)
    upper_cloth_mask = (parsed_np ==4).astype(np.uint8) * 255
    
    # Remove zipper area
    if remove_zipper:
        upper_cloth_mask = remove_zipper_line(upper_cloth_mask)

    
# If DensePose mask is provided, use it to remove arm regions
    if densepose_path is not None:
        I = np.load(densepose_path)  # DensePose part index map
        if I.shape != upper_cloth_mask.shape:
            raise ValueError(f"[ERROR] Shape mismatch: DensePose {I.shape} vs upper_cloth_mask {upper_cloth_mask.shape}")

        # Create a mask for arms (DensePose part indices 15 to 22)
        arms_mask = np.isin(I, [15, 16, 17, 18, 19, 20, 21, 22])
        
        arms_mask = arms_mask.astype(np.uint8)  # cv2는 uint8을 요구함
        kernel = np.ones((17, 17), np.uint8)    # 확장할 크기 조정 가능
        arms_mask = cv2.dilate(arms_mask, kernel, iterations=1)

        arms_mask = arms_mask.astype(bool)      # 다시 bool 타입으로 변환
    
        # Remove arm areas from upper clothing mask
        upper_cloth_mask[arms_mask] = 0
        print(f"[INFO] Removed arms from upper cloth mask using DensePose")
    
    # Save the mask
    upper_cloth_image = Image.fromarray(upper_cloth_mask)
    upper_cloth_image.save(output_mask_path)
    print(f"[INFO] Upper cloth mask saved to: {output_mask_path}")
    
# Example execution
if __name__ == "__main__":
    input_image_path = "datasets/my_vest_data/test/image/suit.jpg"
    output_mask_path = "datasets/my_vest_data/test/agnostic-mask/suit_mask.png"
    densepose_path = "datasets/my_vest_data/test/image-densepose/I.npy"  # DensePose 결과 파일
    os.makedirs(os.path.dirname(output_mask_path), exist_ok=True)
    extract_upper_cloth(input_image_path, output_mask_path, densepose_path=densepose_path)